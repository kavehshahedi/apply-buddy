from enum import Enum


class RelevanceFilters(Enum):
    RELEVANT = 'R'
    RECENT = 'DD'


class TimeFilters(Enum):
    ANY = ''
    DAY = 'r86400'
    WEEK = 'r604800'
    MONTH = 'r2592000'


class TypeFilters(Enum):
    FULL_TIME = 'F'
    PART_TIME = 'P'
    TEMPORARY = 'T'
    CONTRACT = 'C'
    INTERNSHIP = 'I'
    VOLUNTEER = 'V'
    OTHER = 'O'


class ExperienceLevelFilters(Enum):
    INTERNSHIP = '1'
    ENTRY_LEVEL = '2'
    ASSOCIATE = '3'
    MID_SENIOR = '4'
    DIRECTOR = '5'
    EXECUTIVE = '6'


class OnSiteOrRemoteFilters(Enum):
    ON_SITE = '1'
    REMOTE = '2'
    HYBRID = '3'


class IndustryFilters(Enum):
    AIRLINES_AVIATION = '94'
    BANKING = '41'
    CIVIL_ENGINEERING = '51'
    COMPUTER_GAMES = '109'
    ENVIRONMENTAL_SERVICES = '86'
    ELECTRONIC_MANUFACTURING = '112'
    FINANCIAL_SERVICES = '43'
    INFORMATION_SERVICES = '84'
    INVESTMENT_BANKING = '45'
    INVESTMENT_MANAGEMENT = '46'
    IT_SERVICES = '96'
    LEGAL_SERVICES = '10'
    MOTOR_VEHICLES = '53'
    OIL_GAS = '59'
    SOFTWARE_DEVELOPMENT = '4'
    STAFFING_RECRUITING = '104'
    TECHNOLOGY_INTERNET = '6'


class SalaryBaseFilters(Enum):
    SALARY_40K = '1'
    SALARY_60K = '2'
    SALARY_80K = '3'
    SALARY_100K = '4'
    SALARY_120K = '5'
    SALARY_140K = '6'
    SALARY_160K = '7'
    SALARY_180K = '8'
    SALARY_200K = '9'


class JobFunctionFilters(Enum):
    ACCOUNTING_AUDITING = 'acct'
    ADMINISTRATIVE = 'adm'
    ADVERTISING = 'advr'
    BUSINESS_DEVELOPMENT = 'bd'
    CONSULTING = 'cnsl'
    DISTRIBUTION = 'dist'
    DESIGN = 'dsgn'
    EDUCATION = 'edu'
    ENGINEERING = 'eng'
    FINANCE = 'fin'
    GENERAL_BUSINESS = 'genb'
    HEALTH_CARE_PROVIDER = 'hcpr'
    HUMAN_RESOURCES = 'hr'
    INFORMATION_TECHNOLOGY = 'it'
    LEGAL = 'lgl'
    MANAGEMENT = 'mgmt'
    MANUFACTURING = 'mnfc'
    MARKETING = 'mrkt'
    OTHER = 'othr'
    PUBLIC_RELATIONS = 'pr'
    PRODUCT_MANAGEMENT = 'prdm'
    PROJECT_MANAGEMENT = 'prjm'
    QUALITY_ASSURANCE = 'qa'
    RESEARCH = 'rsch'
    SALES = 'sale'
    SUPPLY_CHAIN = 'supl'
    TRAINING = 'trng'


class BenefitsFilters(Enum):
    MEDICAL = '1'
    VISION = '2'
    DENTAL = '3'
    RETIREMENT_401K = '4'
    PENSION_PLAN = '5'
    PAID_MATERNITY_LEAVE = '7'
    PAID_PATERNITY_LEAVE = '8'
    COMMUTER_BENEFITS = '9'
    STUDENT_LOAN_ASSISTANCE = '10'
    TUITION_ASSISTANCE = '11'
    DISABILITY_INSURANCE = '12'


class CommitmentsFilters(Enum):
    DIVERSITY_EQUITY_INCLUSION = '1'
    ENVIRONMENTAL_SUSTAINABILITY = '2'
    WORK_LIFE_BALANCE = '3'
    SOCIAL_IMPACT = '4'
    CAREER_GROWTH_AND_LEARNING = '5'
